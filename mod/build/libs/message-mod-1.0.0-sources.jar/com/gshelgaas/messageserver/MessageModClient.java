package com.gshelgaas.messageserver;

import com.gshelgaas.messageserver.gui.MessageScreenClient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class MessageModClient implements ClientModInitializer {
    private static class_304 openGuiKey;
    private static boolean messageShown = false;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.messagemod.open_gui",
                GLFW.GLFW_KEY_M,
                "category.messagemod.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 != null && !messageShown) {
                client.field_1724.method_7353(
                        class_2561.method_43470("§6[MessageMod] §fНажми §aM §fдля отправки сообщений"),
                        false
                );
                messageShown = true;
            }

            if (openGuiKey.method_1434()) {
                if (client.field_1724 != null) {
                    client.method_1507(new MessageScreenClient());
                }
            }
        });
    }
}