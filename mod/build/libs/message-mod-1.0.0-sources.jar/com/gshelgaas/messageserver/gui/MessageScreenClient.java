package com.gshelgaas.messageserver.gui;

import com.gshelgaas.messageserver.MessageMod;
import com.gshelgaas.messageserver.service.MessageSenderServiceClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public class MessageScreenClient extends class_437 {
    private class_342 messageField;
    private class_4185 sendButton;

    public MessageScreenClient() {
        super(class_2561.method_43470("Отправка сообщения"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        this.messageField = new class_342(
                this.field_22793,
                centerX - 150, centerY - 30,
                300, 20,
                class_2561.method_43470("Введите сообщение")
        );
        this.messageField.method_1880(256);
        this.messageField.method_47404(class_2561.method_43470("Напишите ваше сообщение здесь..."));
        this.method_37063(this.messageField);

        this.sendButton = class_4185.method_46430(
                        class_2561.method_43470("Отправить"),
                        button -> this.onSendButtonPressed()
                )
                .method_46434(centerX - 75, centerY + 10, 150, 20)
                .method_46431();
        this.method_37063(this.sendButton);

        this.method_48265(this.messageField);
    }

    private void onSendButtonPressed() {
        String messageText = this.messageField.method_1882().trim();

        if (messageText.isEmpty()) {
            if (this.field_22787 != null && this.field_22787.field_1724 != null) {
                this.field_22787.field_1724.method_7353(
                        class_2561.method_43470("§c[MessageMod] §fСообщение не может быть пустым"),
                        false
                );
            }
            return;
        }

        this.sendMessageToServer(messageText);
    }

    private void sendMessageToServer(String message) {
        try {
            MessageSenderServiceClient senderService = new MessageSenderServiceClient();
            senderService.sendMessage(message);

            if (this.field_22787 != null && this.field_22787.field_1724 != null) {
                this.field_22787.field_1724.method_7353(
                        class_2561.method_43470("§a[MessageMod] §fСообщение отправлено: §e" + message),
                        false
                );
            }

            MessageMod.LOGGER.info("Сообщение отправлено: {}", message);

        } catch (Exception e) {
            if (this.field_22787 != null && this.field_22787.field_1724 != null) {
                this.field_22787.field_1724.method_7353(
                        class_2561.method_43470("§c[MessageMod] §f" + e.getMessage()),
                        false
                );
            }
            MessageMod.LOGGER.warn("Ошибка отправки: {}", e.getMessage());
        } finally {
            if (this.field_22787 != null) {
                this.field_22787.method_1507(null);
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_27534(
                this.field_22793,
                this.field_22785,
                this.field_22789 / 2,
                this.field_22790 / 2 - 60,
                0xFFFFFF
        );

        context.method_27534(
                this.field_22793,
                class_2561.method_43470("Сообщение будет сохранено в базе данных"),
                this.field_22789 / 2,
                this.field_22790 / 2 - 45,
                0xAAAAAA
        );

        super.method_25394(context, mouseX, mouseY, delta);
    }
}